# CS180 Proj4A: Stitching Photo Mosaics

## The Code

All the code required to generate the images is located in the `main_2.ipynb` file. 

Each helper function is documented within the notebook.

## How to Run the Code

Open the `main_2.ipynb` and run all cells
