# CS180 Proj4A: Stitching Photo Mosaics

## The Code

All the code required to generate the images is located in the `main_final.ipynb` file.

Each helper function is documented within the notebook.

## How to Run the Code

Open the `main_final.ipynb` and run all cells
Note: since images are not provided in the directory of the submission, this could lead to errors when running on local computer
